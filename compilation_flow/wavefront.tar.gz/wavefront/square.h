#ifndef DIM
# define DIM 256
#endif

#ifndef N
# define N 4
#endif

#define BS (DIM/N)
