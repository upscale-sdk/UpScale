#include <stdio.h>
#include <unistd.h>
#include <sys/time.h>

#include "square.h"

unsigned long int square[N][N][BS][BS];
#define SIZE (sizeof(square)/sizeof(long long))

void 
init_matrix()
{
	int i, j, x, y;
	for (i = 0; i < N; ++i) {
		for (j = 0; j < N; ++j) {
			for (x = 0; x < BS; x++) {
				for (y = 0; y < BS; y++) {
					square[i][j][x][y] = 1;		
				}
			}
		}
	}
}

#pragma omp declare target

void extern sequential(int i, int j, unsigned long int square[N][N][BS][BS]);

long
wavefront(unsigned long int square[N][N][BS][BS])
{
	printf("Executing target...\n");

    #pragma omp parallel num_threads(16)
    {
    #pragma omp single
    {
        int i=0;
        int j=0;

        for (i = 0; i < N; i++) {
            for (j = 0; j < N; j++) {
                if (j == 0 && i == 0) {
                    #pragma omp task firstprivate(i,j) \
                    			depend(inout:square[i][j]) 
					{
                    	sequential(i,j,square);
					}
                } else if (i == 0) {
                    #pragma omp task firstprivate(i,j) \
                    			depend(in:square[i][j-1]) \
                                depend(inout:square[i][j]) 
					{
                    	sequential(i,j,square);
					}
                } else if (j == 0) {
                    #pragma omp task firstprivate(i,j) \
                    			depend(in:square[i-1][j])   \
                                depend(inout:square[i][j])
					{
                    	sequential(i,j,square);
					}
                } else {
                    #pragma omp task firstprivate(i,j) \
                    			depend(in:square[i-1][j])   \
                                depend(in:square[i][j-1])   \
                                depend(in:square[i-1][j-1]) \
                                depend(inout:square[i][j])
					{
                    	sequential(i,j,square);
					}
                }		
            }
        }
    }
    }

    printf(".... target finished.\n");

    return square[N - 1][N - 1][BS - 1][BS - 1];
}

#pragma omp end declare target

int
main(void)
{
	int r;

    int n=N, bs=BS;    
	init_matrix();
    
    GOMP_init(0);

    #pragma omp target map(tofrom:square[0:n][0:n][0:bs][0:bs]) map(tofrom: r) device(0)
    {
        r = wavefront(square);
    }

    GOMP_deinit(0);
    
    printf(" DIM    N  #tasks   Result\n");
	printf(" %4d  %2d  %6d  %lu \n", DIM, N, N*N, square[N - 1][N - 1][BS - 1][BS - 1]);

    return 0;
}

