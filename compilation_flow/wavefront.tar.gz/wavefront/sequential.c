
#include "square.h"

void sequential(int i, int j, unsigned long int square[N][N][BS][BS])
{
    int x, y;

    /*
     * Leftmost upper item. All the neighbors are in different blocks
     */
    if (i > 0 && j > 0) {                                  // _________
        square[i][j][0][0] +=                          // | | # | |
            square[i][j - 1][0][BS - 1] +              // ----#----
            square[i - 1][j][BS - 1][0] +              // | |3#2| |
            square[i - 1][j - 1][BS - 1][BS - 1];      // ____#____
    }                                                  // | |1#o| |
    // ----#----
    // | | # | |
    // ____#____
    /* 
     * First column of items. Left neighbors are in the left block
     */
    if (j > 0) {                                           // _________ 
        for (y = 1; y < BS; y++) {                     // | | # | | 
            square[i][j][y][0] +=                  // ----#-----
                square[i][j - 1][y][BS - 1] +      // | | # | | 
                square[i][j][y - 1][0] +           // ____#____
                square[i][j - 1][y - 1][BS - 1];   // | |3#2| | 
        }                                          // ----#----
    }                                              // | |1#o| | 
    // ____#____
    /*
     * First row of items. Upper neighbors are in the upper block
     */
    if (i > 0) {
        for (x = 1; x < BS; x++) {                     // _________
            square[i][j][0][x] +=                  // | | # | | 
                square[i][j][0][x - 1] +           // ----#----
                square[i - 1][j][BS - 1][x] +      // | | #3|2|
                square[i - 1][j][BS - 1][x - 1];   // ____#____
        }                                          // | | #1|o|
    }                                              // ----#----
    // | | # | |
    // ____#_____
    /*
     * Remaining items. All the neighbors are in the same block
     */
    for (x = 1; x < BS; x++) {                             // _________
        for (y = 1; y < BS; y++) {                     // |3|1# | | 
            square[i][j][y][x] +=                  // ----#----
                square[i][j][y][x - 1] +           // |2|o# | |
                square[i][j][y - 1][x] +           // ____#____
                square[i][j][y - 1][x - 1];        // | | # | |
        }                                          // ----#----
    }                                              // | | # | |

}

